package com.example.grand_arabia_hotel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
